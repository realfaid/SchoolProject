package com.example.schoolproject;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import static com.example.schoolproject.Settings.texr;

public class LedActivity extends AppCompatActivity {
    private static Button On, Off, Red;


    @Override

    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.modes_layout);

        AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);

        ImageView colorActive = findViewById(R.id.colorActive);

        On = (Button) findViewById(R.id.btnOn);
        Off = (Button) findViewById(R.id.btnOff);
        Red = (Button) findViewById(R.id.btnRed);


        On.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                On process1 = new On();
                process1.execute();

            }
        });

        Off.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Off process1 = new Off();
                process1.execute();

            }
        });
        Red.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                barvaZmena();

            }
        });


    }




    public void barvaZmena() {
        ImageView colorActive = findViewById(R.id.colorActive);
        colorActive.setColorFilter(getResources().getColor(R.color.colorRed));

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.settings_menu:
                setContentView(R.layout.settings_layout);
                return true;

            case R.id.help_menu:
                setContentView(R.layout.help_layout);
                return true;

            case R.id.modes_menu:
                setContentView(R.layout.modes_layout);
                return true;

            case R.id.information_menu:
                setContentView(R.layout.information_layout);
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }
    }

}